package Tests;

import org.junit.Test;
import Helpers.GetDetailById;




public class OmdbTests {
	GetDetailById getdetailByID=new GetDetailById();

	String apiKey = System.getProperty("apiKey","27a64b9f");
	String searchWord = System.getProperty("searchWord","harry potter");
	String movieTitle = System.getProperty("movieTitle","Harry Potter and the Sorcerer's Stone");

	@Test
	public void checkMovieId(){
		
		getdetailByID.getIdFromMovie(apiKey, searchWord, movieTitle);
	}
	@Test
	public void checkMovieDetails() {

		String id = getdetailByID.getIdFromMovie(apiKey, searchWord, movieTitle);
		getdetailByID.searchByID(apiKey, id);
	}

}
