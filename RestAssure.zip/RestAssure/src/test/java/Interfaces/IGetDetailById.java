package Interfaces;

public interface IGetDetailById {
	public void searchByID(String apiKey, String id);
}
