package Interfaces;

public interface IGetMovieId {
	
	public String getIdFromMovie(String apiKey, String searchWord, String movieTitle);

}
