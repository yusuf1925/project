package Helpers;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.emptyOrNullString;
import static org.hamcrest.Matchers.not;

import Interfaces.IGetDetailById;

public class GetDetailById extends GetMovieId
implements IGetDetailById
{
	public void searchByID(String apiKey, String id) {
	given()
		.param("apikey", apiKey)
		.param("i",id)
	.when()
		.get()
	.then()
		.log()
		.all()
		.statusCode(200)
		.body("Title", not(emptyOrNullString()))
		.body("Year", not(emptyOrNullString()))
		.body("Released", not(emptyOrNullString()));

	}

}
