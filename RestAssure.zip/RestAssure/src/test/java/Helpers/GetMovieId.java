package Helpers;
import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

import Interfaces.IGetMovieId;

import static io.restassured.RestAssured.given;
import static org.hamcrest.Matchers.emptyOrNullString;
import static org.hamcrest.Matchers.not;

public class GetMovieId implements IGetMovieId {

	String baseURI = System.getProperty("baseURI","http://www.omdbapi.com/");

	private Response getResponseFromEndPoint(String apiKey, String searchWord) {

		return given()
				.param("apikey", apiKey)
				.param("s", searchWord)
	.when()
				.get()
	.then()
				.log()
				.all()
				.contentType(ContentType.JSON)
				.statusCode(200)
	.and()
				.body("Search.Title",not(emptyOrNullString()))
				.body("Search.Year",not(emptyOrNullString()))
				.extract()
				.response();

	}
 public String getIdFromMovie(String apiKey, String searchWord, String movieTitle) {
		RestAssured.baseURI = baseURI;

		String id=null;
		Response response = getResponseFromEndPoint(apiKey,searchWord);
		JsonPath jsonPath = response.jsonPath();
		int count = jsonPath.getInt("Search.size()");
		for(int i=0;i<count;i++)
		{
			String search = jsonPath.getString("Search["+i+"].Title");
			if(search.equalsIgnoreCase(movieTitle))
			{
				id = jsonPath.getString("Search["+i+"].imdbID");

			}
		}
		return id; 

	}


}